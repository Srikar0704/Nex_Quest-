document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('search-bar');
    const suggestionsBox = document.getElementById('suggestions');

    const games = [
        'Cyberpunk 2077', 'Spider-Man Remastered', 'Assassin\'s Creed II',
        'Batman: Arkham Asylum', 'GTA V', 'RDR 2', 'Star Wars Jedi: Fallen Order',
        'Resident Evil 4', 'Far Cry 6', 'Forza Horizon 5', 'Forza Horizon 4',
        'Burnout Paradise', 'Dirt Rally 2.0', 'Need for Speed Heat', 'Asphalt 9: Legends',
        'Forza Motorsport', 'Project CARS 2', 'Wreckfest', 'F1 23', 'The Crew 2',
        'CS:GO', 'Apex Legends', 'Valorant', 'Call of Duty: Warzone', 'Dota 2',
        'PUBG: Battlegrounds', 'Fortnite', 'Halo Infinite', 'Diablo III',
        'Dead by Daylight', 'Phasmophobia', 'Amnesia: The Dark Descent', 'Pathologic',
        'Resident Evil 7: Biohazard', 'The Cat Lady', 'Amnesia: The Bunker',
        'Little Nightmares II', 'The Outlast Trials', 'Alan Wake 2'
    ];

    searchInput.addEventListener('input', () => {
        const query = searchInput.value.toLowerCase();
        suggestionsBox.innerHTML = '';
        if (query) {
            const filteredGames = games.filter(game => game.toLowerCase().includes(query));
            filteredGames.forEach(game => {
                const suggestionDiv = document.createElement('div');
                suggestionDiv.textContent = game;
                suggestionDiv.addEventListener('click', () => {
                    searchInput.value = game;
                    suggestionsBox.innerHTML = '';
                    suggestionsBox.style.display = 'none';
                    window.location.href = game.toLowerCase().replace(/ /g, '-') + '.html';
                });
                suggestionsBox.appendChild(suggestionDiv);
            });
            suggestionsBox.style.display = 'block';
        } else {
            suggestionsBox.style.display = 'none';
        }
    });

    document.addEventListener('click', (e) => {
        if (!e.target.closest('.search-container')) {
            suggestionsBox.innerHTML = '';
            suggestionsBox.style.display = 'none';
        }
    });
});
