window.addEventListener("load", function() {
    // Add class to main content to trigger animation
    document.querySelector('main').classList.add('main-visible');
});


// function addBlurExcept(event) {
//     var gameItems = document.querySelectorAll('.game-item');
//     var targetItem = event.currentTarget;
//     gameItems.forEach(item => {
//         if (item !== targetItem) {
//             item.classList.add('blur');
//         }
//     });
// }

// function removeBlur() {
//     var gameItems = document.querySelectorAll('.game-item');
//     gameItems.forEach(item => {
//         item.classList.remove('blur');
//     });
// }

// document.querySelectorAll('.game-item').forEach(item => {
//     item.addEventListener('mouseover', addBlurExcept);
//     item.addEventListener('mouseleave', removeBlur);
// });

document.querySelectorAll('.genre-section').forEach(section => {
    const scrollContainer = section.querySelector('.game-list');
    const btnPrev = section.querySelector('.btn-prev');
    const btnNext = section.querySelector('.btn-next');
    const scrollStep = 300; // Adjust the scroll step as needed

    btnPrev.addEventListener('click', () => {
        scrollContainer.scrollBy({
            left: -scrollStep,
            behavior: 'smooth'
        });
    });

    btnNext.addEventListener('click', () => {
        scrollContainer.scrollBy({
            left: scrollStep,
            behavior: 'smooth'
        });
    });

    // Show navigation buttons when game-list is hovered or navigation button is hovered
    scrollContainer.addEventListener('mouseenter', () => {
        section.querySelector('.navigation-buttons').style.display = 'flex';
    });

    section.querySelector('.navigation-buttons').addEventListener('mouseenter', () => {
        section.querySelector('.navigation-buttons').style.display = 'flex';
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('search-bar');
    const suggestionsBox = document.getElementById('suggestions');

    const games = [
        'Cyberpunk 2077', 'Spider-Man Remastered', 'Assassin\'s Creed II',
        'Batman: Arkham Asylum', 'GTA V', 'RDR 2', 'Star Wars Jedi: Fallen Order',
        'Resident Evil 4', 'Far Cry 6', 'Forza Horizon 5', 'Forza Horizon 4',
        'Burnout Paradise', 'Dirt Rally 2.0', 'Need for Speed Heat', 'Asphalt 9: Legends',
        'Forza Motorsport', 'Project CARS 2', 'Wreckfest', 'F1 23', 'The Crew 2',
        'CS:GO', 'Apex Legends', 'Valorant', 'Call of Duty: Warzone', 'Dota 2',
        'PUBG: Battlegrounds', 'Fortnite', 'Halo Infinite', 'Diablo III',
        'Dead by Daylight', 'Phasmophobia', 'Amnesia: The Dark Descent', 'Pathologic',
        'Resident Evil 7: Biohazard', 'The Cat Lady', 'Amnesia: The Bunker',
        'Little Nightmares II', 'The Outlast Trials', 'Alan Wake 2'
    ];

    // Create a mapping for all games
    const gameFileMapping = {
        'Cyberpunk 2077': 'cyberpunk.html',
        'Spider-Man Remastered': 'spider-man.html',
        'Assassin\'s Creed II': 'assasin\'s-creed.html',
        'Batman: Arkham Asylum': 'batmanArkham.html',
        'GTA V': 'gta5.html',
        'RDR 2': 'rdr2.html',
        'Star Wars Jedi: Fallen Order': 'StarWars_FallenOrder.html',
        'Resident Evil 4': 'residentEvil4.html',
        'Far Cry 6': 'FarCry6.html',
        'Forza Horizon 5': 'forzahorizon5.html',
        'Forza Horizon 4': 'forzahorizon4.html',
        'Burnout Paradise': 'burnoutparadise.html',
        'Dirt Rally 2.0': 'dirtrally2-0.html',
        'Need for Speed Heat': 'needforspeedheat.html',
        'Asphalt 9: Legends': 'asphalt9legends.html',
        'Forza Motorsport': 'forza-motorsport.html',
        'Project CARS 2': 'project-cars-2.html',
        'Wreckfest': 'wreckfest.html',
        'F1 23': 'f1-23.html',
        'The Crew 2': 'the-crew-2.html',
        'CS:GO': 'cs-go.html',
        'Apex Legends': 'apex-legends.html',
        'Valorant': 'valorant.html',
        'Call of Duty: Warzone': 'call-of-duty-warzone.html',
        'Dota 2': 'dota-2.html',
        'PUBG: Battlegrounds': 'pubg-battlegrounds.html',
        'Fortnite': 'fortnite.html',
        'Halo Infinite': 'halo-infinite.html',
        'Diablo III': 'diablo-iii.html',
        'Dead by Daylight': 'dead-by-daylight.html',
        'Phasmophobia': 'phasmophobia.html',
        'Amnesia: The Dark Descent': 'amnesia-the-dark-descent.html',
        'Pathologic': 'pathologic.html',
        'Resident Evil 7: Biohazard': 'resident-evil-7-biohazard.html',
        'The Cat Lady': 'the-cat-lady.html',
        'Amnesia: The Bunker': 'amnesia-the-bunker.html',
        'Little Nightmares II': 'little-nightmares-ii.html',
        'The Outlast Trials': 'the-outlast-trials.html',
        'Alan Wake 2': 'alan-wake-2.html'
    };

    searchInput.addEventListener('input', () => {
        const query = searchInput.value.toLowerCase();
        suggestionsBox.innerHTML = '';
        if (query) {
            const filteredGames = games.filter(game => game.toLowerCase().includes(query));
            filteredGames.forEach(game => {
                const suggestionDiv = document.createElement('div');
                suggestionDiv.textContent = game;
                suggestionDiv.addEventListener('click', () => {
                    const gameFile = gameFileMapping[game];
                    if (gameFile) {
                        window.location.href = gameFile;
                    } else {
                        console.error('No mapping found for the selected game.');
                    }
                });
                suggestionsBox.appendChild(suggestionDiv);
            });
            suggestionsBox.style.display = 'block';
        } else {
            suggestionsBox.style.display = 'none';
        }
    });

    document.addEventListener('click', (e) => {
        if (!e.target.closest('.search-container')) {
            suggestionsBox.innerHTML = '';
            suggestionsBox.style.display = 'none';
        }
    });
});
