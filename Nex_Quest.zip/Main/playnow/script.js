document.addEventListener('DOMContentLoaded', () => {
    const basket = document.querySelector('.basket');
    const ball = document.querySelector('.ball');
    const gameContainer = document.querySelector('.game-container');
    const containerWidth = gameContainer.clientWidth;
    const containerHeight = gameContainer.clientHeight;
    const basketWidth = basket.clientWidth;

    let ballInterval;
    let ballFallingSpeed = 3;
    let score = 0;

    // Move basket with arrow keys
    document.addEventListener('keydown', (e) => {
        const left = parseInt(window.getComputedStyle(basket).left);

        if (e.key === 'ArrowLeft' && left > 0) {
            basket.style.left = `${left - 20}px`;
        } else if (e.key === 'ArrowRight' && left < containerWidth - basketWidth) {
            basket.style.left = `${left + 20}px`;
        }
    });

    // Start the ball falling
    function startGame() {
        ball.style.top = '0';
        ball.style.left = `${Math.floor(Math.random() * (containerWidth - 20))}px`;

        ballInterval = setInterval(() => {
            const ballTop = parseInt(window.getComputedStyle(ball).top);
            ball.style.top = `${ballTop + ballFallingSpeed}px`;

            // Check if the ball hit the bottom
            if (ballTop >= containerHeight - 20) {
                clearInterval(ballInterval);
                alert(`Game Over! Your score is ${score}`);
                score = 0;
                startGame();
            }

            // Check if the ball is caught by the basket
            const ballLeft = parseInt(window.getComputedStyle(ball).left);
            const basketLeft = parseInt(window.getComputedStyle(basket).left);

            if (
                ballTop >= containerHeight - 40 &&
                ballLeft >= basketLeft &&
                ballLeft <= basketLeft + basketWidth
            ) {
                clearInterval(ballInterval);
                score++;
                ballFallingSpeed += 0.5; // Increase the speed each time a ball is caught
                startGame();
            }
        }, 20);
    }

    startGame();
});
